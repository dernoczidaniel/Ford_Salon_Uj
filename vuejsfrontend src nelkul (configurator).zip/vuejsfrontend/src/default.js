

Userfront.login({
  // ...
  Email: "member@example.com",
});

// Is the same as

Userfront.login({
  // ...
  email: "member@example.com",
});

// Or you can use "username"

Userfront.login({
  // ...
  username: "member1234",
});

