<template>

<!-- Források        mb-5 alsó margó -->
<div class="container-fluid p-5 BodySize">
        <div class="row gx-5 mt-0 ">

            <div class="col-lg-12 " >
                <div class="mb-4">
                    <h3 class="display-6 text-uppercase mb-0">Források </h3>
                </div>
                
                

                <p class="mb-4">
                    https://www.ford.com/ <br>
                    https://www.ford.hu/ <br>
                    https://www.ford.hu/szemelyautok-szemelyszallitok/s-max <br>
                    https://hu.wikipedia.org/wiki/Ford_Motor_Company <br>
                    https://en.wikipedia.org/wiki/Ford_Motor_Company<br>
                    https://www.ksh.hu/docs/hun/xstadat/xstadat_evkozi/e_ode001b.html <br>
                    https://www.caranddriver.com/research/a32766752/car-sale-contract-what-you-need-to-know/ <br>
                    https://corporate.ford.com/articles/products/new-tech-team-members-transforming-ford.html<br>
                    https://en.wikipedia.org/wiki/Jim_Farley_(businessman)<br>
                    https://www.carnet.hu/ford/ <br>
                </p>

                <a href="/" class="btn btn-primary py-2 px-5">Kezdőlap</a>
                
            </div>
        </div>
    </div>
<!-- vége -->


</template>