<template>

<!-- rólunk -->
<div class="container-fluid p-5">
    <div class="row gx-5">
       
        <div class="col-lg-12">
            <div class="mb-4">
                <h1 class="display-3 text-uppercase mb-0"> Rólunk </h1>
            </div>

            <br>

            <table>
                <tr>
                  <td>
                    <img src="../assets/img/About_us/jim-farley.jpg" width="440px" height="300px" >
                  </td>
                  <td>
                    <div class="container-fluid p-5">
                    <h3 class=" text-uppercase mb-0">Jim Farley (Vezér igazgató) </h3>
                    James D. Farley Jr. (született: 1962. június 10.) 
                    amerikai üzletember, a Ford vezérigazgatója és a Harley-Davidson igazgatótanácsának tagja . 
                    Autóipari karrierjét nagyapja ihlette, 
                    aki 1918-ban kezdett dolgozni Henry Ford River Rouge - i üzemében.
                    Farley egy bankár apától született Buenos Airesben, Argentínában, ahol első éveit töltötte, mielőtt a Connecticut állambeli Greenwichbe költözött . 
                    Az egyetem előtt Farley a Portsmouth Abbey School-ba járt, egy főiskolai előkészítő iskolába a Rhode Island állambeli Portsmouthban. 
                    A Georgetown Egyetemen , majd később a Kaliforniai Egyetemen szerzett diplomát. Chris Farley , Kevin Farley és John Farley előadók unokatestvére .
                    Mielőtt 2007 novemberében csatlakozott a Fordhoz, Farley a Lexus csoport alelnöke és vezérigazgatója volt , 
                    aki a Toyota luxusautó-márkájával kapcsolatos összes értékesítési, marketing- és ügyfél-elégedettségi tevékenységért volt felelős . 
                    2019 májusa és 2020 februárja között Farley az új üzletek, technológia és stratégia részlegének elnöke volt. 
                    2017 júniusától 2019 májusáig a Global Markets ügyvezető alelnökeként és elnökeként dolgozott. 
                    2015 és 2017 között a Ford Europe vezérigazgatója és elnöke volt .2020. augusztus 4-én a Ford bejelentette, 
                    hogy Farley 2020. október 1-jén Jim Hackettet követi a Ford vezérigazgatói posztján. Ezzel egy időben bejelentették, hogy Hackett visszavonul, 
                    és különleges tanácsadó lesz. 2021 júliusában a cég vezérigazgatója , 
                    Jochen Zeitz Farley-t jelölte a Harley-Davidson igazgatótanácsába annak érdekében, 
                    hogy új életre keltse a motorkerékpár-gyártót, és felkészítse az elektromos jövőre.
                    </div>
                </td>
                </tr>
              
              </table>


            <br>

            <table>
                <tr>
                  
                  <td>
                    <div class="container-fluid p-5">
                    <h3 class=" text-uppercase mb-0">Csapatunkról </h3>

                    SzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzöveg
                    SzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzöveg
                    SzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzöveg
                    SzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzöveg
                    SzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzöveg
                    SzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzöveg
                    SzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzövegSzöveg
                    </div>

                    <td>
                        <img src="../assets/img/About_us/team.jpeg" width="500px" height="300px" >
                      </td>
                </td>
                </tr>
              
              </table>
        
              <a href="/" class="btn btn-primary py-2 px-5 m1">Kezdőlap</a>
        </div>
    </div>
</div>
<!-- rólunk vége -->


</template>