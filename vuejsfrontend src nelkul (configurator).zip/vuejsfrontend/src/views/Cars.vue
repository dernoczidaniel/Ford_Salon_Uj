<template>


    <!-- Kocsik -->
    <div class="container-fluid p-0 mb-5 ">
        <div class="mb-0 text-center p-5 CarsHeader">

            <h1 class="display-3 text-uppercase mb-0 text-light">Modellek</h1> <!-- cím -->



            <div class="container-fluid  center ">




                <div class="row ">
                    <div class="col-lg-12 position-relative">
                        <div class="input-group mb-2 p-5 ">
                            <span class="input-group-text " id="basic-addon1">Kereső: </span>
                            <input type="search" class="form-control " placeholder="írja be az autó nevét..."
                                aria-label="kereso" aria-describedby="basic-addon1">
                        </div>
                    </div>
                </div>






                <div class="row ">
                    <div class="col-lg-12 position-relative">
                        <div class="mb-2 p-5 ">
                            <a class="btn btn-light m-1" style="color: black;">Szűrő:</a>
                            <a class="btn btn-dark m-1" style="color: lightblue;">Mild Hibrid</a>
                            <a class="btn btn-dark m-1" style="color: lightgreen;">Elektromos</a>
                            <a class="btn btn-dark m-1" style="color: gray;">Benzines</a>
                            <a class="btn btn-dark m-1" style="color: orange;">Családi</a>
                            <a class="btn btn-dark m-1" style="color: blue;">Sport</a>
                            <a class="btn btn-dark m-1" style="color: brown;">Terep</a>


                        </div>
                    </div>
                </div>

            </div>






        </div>


        <div class="col-md-12 p-5">



            <div class="row g-5 ">
                <div class="col-lg-4 col-md-6">
                    <div class="team-item position-relative">
                        <div class="position-relative overflow-hidden rounded">
                            <img class="img-fluid w-100" src="../assets/img/Cars/Focus/Icon.png" alt="Focus">







                            <!-- Autó képe -->
                            <div class="team-overlay">
                                <div class="d-flex align-items-center justify-content-start">



                                    <!-- Autó rövid lerás -->

                                    <div class="container-fluid p-0">
                                        <div class="mb-5 text-center">
                                            <div class="row g-60">
                                                <div class="col-lg-20 col-md-20">

                                                    <p class="text-light mb-4">Ajánlott kedvezményes
                                                        ár (az áfá-t tartalmazza) <br>
                                                        10 410 000 Ft
                                                        10 410 000 Ft -tól listaáron
                                                    </p>


                                                    <a class="btn btn-light  mx-1 m-1" href="#">Konfigurálás</a>
                                                    <a class="btn btn-light  mx-1 m-1" href="#">További információ</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Autó rövid lerás vége -->



                                </div>
                            </div>
                        </div>
                        <div class="position-absolute start-0 bottom-0 w-100 rounded-bottom text-center p-4"
                            style="background: rgba(34, 36, 41, .9);">

                            <h5 class="text-uppercase text-light">Ford Focus Titanium</h5> <!-- Autó neve -->

                        </div>
                    </div>
                    <a class="btn btn-dark m-1" style="color: lightblue;">Mild Hibrid</a>
                    <a class="btn btn-dark m-1" style="color: orange;">Családi</a>


                </div>



                <!-- -------------------------------------------------------------------------------------------------------------------------------------- -->



                <div class="col-lg-4 col-md-6">
                    <div class="team-item position-relative">
                        <div class="position-relative overflow-hidden rounded">
                            <img class="img-fluid w-100" src="../assets/img/Cars/Mustang Mach-E/Icon.png" alt="Mach-E">
                            <div class="team-overlay">
                                <div class="d-flex align-items-center justify-content-start">


                                    <!-- Autó rövid lerás -->

                                    <div class="container-fluid p-0">
                                        <div class="mb-5 text-center">
                                            <div class="row g-60">
                                                <div class="col-lg-20 col-md-20">

                                                    <p class="text-light mb-4">Ajánlott kedvezményes ár
                                                        (az áfá-t tartalmazza) <br>
                                                        27 850 000 Ft
                                                        28 350 000 Ft -tól listaáron
                                                    </p>


                                                    <a class="btn btn-light  mx-1" href="#">Konfigurálás</a>
                                                    <a class="btn btn-light  mx-1" href="#">További információ</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Autó rövid lerás vége -->


                                </div>
                            </div>
                        </div>
                        <div class="position-absolute start-0 bottom-0 w-100 rounded-bottom text-center p-4"
                            style="background: rgba(34, 36, 41, .9);">
                            <h5 class="text-uppercase text-light">Ford Mustang Mach-E</h5>
                        </div>
                    </div>
                    <a class="btn btn-dark m-1" style="color: lightgreen;">Elektromos</a>
                    <a class="btn btn-dark m-1" style="color: orange;">Családi</a>

                </div>





                <div class="col-lg-4 col-md-6">
                    <div class="team-item position-relative">
                        <div class="position-relative overflow-hidden rounded">
                            <img class="img-fluid w-100" src="../assets/img/Cars/Mustang/Icon.png" alt="Mustang">
                            <div class="team-overlay">
                                <div class="d-flex align-items-center justify-content-start">


                                    <!-- Autó rövid lerás -->

                                    <div class="container-fluid p-0">
                                        <div class="mb-5 text-center">
                                            <div class="row g-60">
                                                <div class="col-lg-20 col-md-20">

                                                    <p class="text-light mb-4">Ajánlott kedvezményes
                                                        ár (az áfá-t tartalmazza) <br>
                                                        22 500 000 Ft
                                                        22 500 000 Ft -tól listaáron
                                                    </p>


                                                    <a class="btn btn-light  mx-1" href="#">Konfigurálás</a>
                                                    <a class="btn btn-light  mx-1" href="#">További információ</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Autó rövid lerás vége -->
                                </div>
                            </div>
                        </div>

                        <div class="position-absolute start-0 bottom-0 w-100 rounded-bottom text-center p-4"
                            style="background: rgba(34, 36, 41, .9);">
                            <h5 class="text-uppercase text-light">Ford Mustang GT</h5>

                        </div>
                    </div>
                    <a class="btn btn-dark m-1" style="color: gray;">Benzines</a>
                    <a class="btn btn-dark m-1" style="color: blue;">Sport</a>

                </div>






                <div class="col-lg-4 col-md-6">
                    <div class="team-item position-relative">
                        <div class="position-relative overflow-hidden rounded">
                            <img class="img-fluid w-100" src="../assets/img/Cars/Ranger Raptop/Icon.png" alt="Ranger">
                            <div class="team-overlay">
                                <div class="d-flex align-items-center justify-content-start">

                                    <!-- Autó rövid lerás -->

                                    <div class="container-fluid p-0">
                                        <div class="mb-5 text-center">
                                            <div class="row g-60">
                                                <div class="col-lg-20 col-md-20">

                                                    <p class="text-light mb-4">Ajánlott kedvezményes
                                                        ár (az áfá-t tartalmazza) <br>
                                                        18 884 900 Ft
                                                        18 865 850 Ft -tól listaáron
                                                    </p>


                                                    <a class="btn btn-light  mx-1" href="#">Konfigurálás</a>
                                                    <a class="btn btn-light  mx-1" href="#">További információ</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Autó rövid lerás vége -->


                                </div>
                            </div>
                        </div>
                        <div class="position-absolute start-0 bottom-0 w-100 rounded-bottom text-center p-4"
                            style="background: rgba(34, 36, 41, .9);">
                            <h5 class="text-uppercase text-light">Ford Ranger Raptor</h5>


                        </div>
                    </div>
                    <a class="btn btn-dark m-1" style="color: gray;">Benzines</a>
                    <a class="btn btn-dark m-1" style="color: brown;">Terep</a>

                </div>






                <div class="col-lg-4 col-md-6">
                    <div class="team-item position-relative">
                        <div class="position-relative overflow-hidden rounded">
                            <img class="img-fluid w-100" src="../assets/img/Cars/S-Max/Icon.png" alt="S-MAX">
                            <div class="team-overlay">
                                <div class="d-flex align-items-center justify-content-start">
                                    <!-- Autó rövid lerás -->

                                    <div class="container-fluid p-0">
                                        <div class="mb-5 text-center">
                                            <div class="row g-60">
                                                <div class="col-lg-20 col-md-20">

                                                    <p class="text-light mb-4">Ajánlott kedvezményes
                                                        ár (az áfá-t tartalmazza) <br>
                                                        14 160 000 Ft
                                                        14 160 000 Ft -tól listaáron
                                                    </p>


                                                    <a class="btn btn-light  mx-1" href="#">Konfigurálás</a>
                                                    <a class="btn btn-light  mx-1" href="#">További információ</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Autó rövid lerás vége -->
                                </div>
                            </div>
                        </div>
                        <div class="position-absolute start-0 bottom-0 w-100 rounded-bottom text-center p-4"
                            style="background: rgba(34, 36, 41, .9);">
                            <h5 class="text-uppercase text-light">Ford S-MAX</h5>


                        </div>
                    </div>
                    <a class="btn btn-dark m-1" style="color: gray;">Benzines</a>
                    <a class="btn btn-dark m-1" style="color: orange;">Családi</a>
                </div>





                <!-- !!!!!!!!!!!!!!!!!!!!!!!! -->
                <div class="col-lg-4 col-md-6">
                    <div class="team-item position-relative">
                        <div class="position-relative overflow-hidden rounded">
                            <img class="img-fluid w-100" src="../assets/img/Cars/S-Max/Icon.png" alt="modell">
                            <div class="team-overlay">
                                <div class="d-flex align-items-center justify-content-start">
                                    <!-- Autó rövid lerás -->

                                    <div class="container-fluid p-0">
                                        <div class="mb-5 text-center">
                                            <div class="row g-60">
                                                <div class="col-lg-20 col-md-20">

                                                    <p class="text-light mb-4">

                                                        leirás

                                                    </p>


                                                    <a class="btn btn-light  mx-1" href="#">Konfigurálás</a>
                                                    <a class="btn btn-light  mx-1" href="#">További információ</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Autó rövid lerás vége -->
                                </div>
                            </div>
                        </div>
                        <div class="position-absolute start-0 bottom-0 w-100 rounded-bottom text-center p-4"
                            style="background: rgba(34, 36, 41, .9);">
                            <h5 class="text-uppercase text-light">Modell</h5>
                        </div>
                    </div>
                    <a class="btn btn-dark m-1" style="color: red;" href="cars.html/#stock">Nincs Készleten</a>

                </div>
            </div>
        </div>
        <!-- Kocsik vége -->
    </div>

    <a href="/ConfiguratorStep1">Konfigurator test</a>

</template>