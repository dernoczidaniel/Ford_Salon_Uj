<script setup>
import DataService from "../services/dataservice"
import { ref, onMounted  } from 'vue'

const model = ref("Mustang");
const colors = ref(["red","black","whie"]);
const interiorcolors = ref([""]);
const extras = ref([""]);
const motor = ref("1.9 TDI");

const color = ref("");


DataService.getAllColor()
  .then((resp) => {
    colors.value = resp;
    console.log(colors.value);
  })
  .catch((err) => {
    console.log(err);
  });

  const szinValasztas = () => {
  valasztottId.value = colors.value.find((t) => t.nev === valasztas.value)._id;
  console.log(valasztottId.value);
  color.value = color.value.filter(
    (t) => t.gyarto === valasztottId.value
  );
  console.log(color.value);
};
</script>


<template>
    <div class="container-fluid mt-0 center  ">
        <div class="position-relative">
            <div class="row gx-5">
                <div class="col-lg-6">

                    <div class="m-4 p-4">

                        <div class="mb-4">
                            <h3 class="display-6 text-uppercase mb-2">Konfigurátor</h3>
                            <h5 class="display-6 text-uppercase mb-2">{{model}}</h5>

                        </div>


                        <div class="mb-3">
                            <table>


                                <div v-if="color.value === red">
                                <td>
                                    <img src="../assets/img/Cars/Mustang/GT/GT.jpg" alt="car" width="550" height="300">
                                </td>
                                </div>


                                <div v-if="interiorcolors.value === red">
                                <td>
                                    <img src="../assets/img/Cars/Mustang/GT/Interior/Ceramic.png" alt="" width="550" height="300">
                                </td>
                                </div>  


                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="mb-0 col-lg-12 p-5 ColorMenu">
        <div class="center">

            <select v-model="szinValasztas" @change="color">
                <option v-for="color in colors">{{ color }}</option>
            </select>

            <select v-model="valasztas" @change="valaszto">
                <option v-for="interiorcolor in interiorcolors">{{ interiorcolor }}</option>
            </select>

            <select v-model="valasztas" @change="valaszto">
                <option v-for="extra in extras">{{ extra }}</option>
            </select>

            <select v-model="valasztas" @change="valaszto">
                <option>{{ motor }}</option>
            </select>

            {{ color }}
        </div>


        <div class="input-group mb-3 right">
            <div class="input-group mb-3 right">
                <a href="/ConfiguratorStep2">


                    <button class="btn btn-outline-secondary m-1" type="button">Mentés</button>

                    <button class="btn btn-outline-secondary  m-1" type="button">Tovább</button>

                </a>
            </div>
        </div>
    </div>

    <div class="container-fluid mt-0 p-5">
        <h2>FŐBB JELLEMZŐK</h2>
        <p>
            Négy króm kipufogóvég (aktív hangerőszabályozással)
            Aktív kipufogó rendszer (hangerőszabályzással)
            Karosszéria színével megegyező színű tükörház fényezés és hátsó spoiler
            Egyedi GT lökhárító
            Fekete hűtőrács króm Pony logoval
            Króm Pony logo a hűtőrácson, GT felirat hátul és 5.0 embléma az első sárvédőkön
            Fekete könnyűfém felni - Elöl: 19"x 9.0" - Hátul 19"x 9.5"
            Elöl: 255/40R19 gumi Hátul: 275/40R19 gumi
            Elektromosan állítható, behajtható (automatikus), fűthető külső visszapillantó tükrök, tükörházba integrált
            kilépővilágítással
            LED fényszórók
            LED hátsó lámpák
            Laminált szélvédő
            Fekete féknyergek
            Gumijavító készlet
            Sebességváltó fülek a kormányon- automata váltó esetén
            Kétzónás automata klímaberendezés
            12"-os digitális kijelző a kormánykerék mögött
            Aluminium pedálok
            Elektromosan, 6-irányban (előre/hátra, fel/le, háttámla előre-hátra) álítható első ülések, statikus (nem
            állítható) deréktámasszal
            Első szőnyegek - fekete, szövet
            Belső hangulatfény
            Bőrborítású kormánykerék
            Bőrborítású kézifékkar
            Megvilágított küszöbborítás
            Elektronikus Line Lock - pályaalkalmazás, az első kerekeket blokkolja, miközben a hátsó kerekek
            kipöröghetnek
            felmelegítve a gumiabroncsokat, elősegítve a legoptimálisabb kigyorsítást
            Rajtautomatika (manuális váltó esetén)
            Hatdugattyús BremboTM első féknyergek
            Fűthető kormánykerék
            Választható vezetési módok
            CD-rádiós audiorendszer
            9 hangszóró
            8"-os színes érintőképernyős kijelző
            SYNC 3 - Bluetooth kihangosító és hangvezérlő rendszer
            Automatikus távolsági fényszóróvezérlés
            Automatikus fényszóróvezérlés (ki- és bekapcsolás)
            Ütközésmegelőző rendszer (kamera és radar alapú)
            Visszagurulásgátló
            Hátsó parkolóradar
            Keréknyomásfigyelő rendszer
            ISOFIX előkészítés - mindkét hátsó ülésen
            Tolatókamera
            Adaptív sebességtartó automatika
            Sávelhagyásra figyelmeztető rendszer
        </p>
    </div>
</template>