<script setup>

</script>

<template>
    <!-- kezd -->
    <div class="container-fluid p-0 mb-5" > 
        <div id="header-carousel" class="carousel slide" data-bs-ride="carousel" >
            <div class="carousel-inner" >
                <div class="carousel-item active" >
                    <img style="width:100%; height: 500px;" src="../assets/img/Header/History.jpg" alt="History" >
                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 800px;">
                            <h1 class="display-2 text-white text-uppercase mb-md-4">A Ford Története</h1>                   
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!--  Vége -->

    



<!-- Bemutatkozás -->
    <div class="container-fluid p-5">
        <div class="row gx-5">

            <div class="col-lg-12">
                <div class="mb-4">
                    <h3 class="display-6 text-uppercase mb-0">Ford Motor Company </h3>
                </div>
                
                

                <p class="mb-4"> 
                    A Ford Motor Company amerikai multinacionális vállalat, 
                    amit Henry Ford 1903. június 16-án Lansingben alapított 11 társával együtt, 
                    mindössze 28 000 dollár készpénzből. 
                    A világ egyik legnagyobb ipari vállalatának fejlődése szorosan összekapcsolódik 
                    az Amerikai Egyesült Államok XX. századi ipari fejlődésével.
                </p>

                <div class="mb-4">
                    <h3 class="display-6 text-uppercase mb-0">Története</h3>
                </div>
                
                

                <p class="mb-4"> 
                    A század elejétől fogva az amerikai ipar egyet jelent a Ford névvel. A Ford gyár az alapítás idején egy átalakított kis detroiti vagongyárat jelentett 10 fő alkalmazottal.

                    Henry Ford irányításával az első 15 hónapban 1700 autó hagyta el a gyárat. A gépkocsik 1903 és 1908 között az ábécé első 19 betűjét viselték. A korai gyártmányok közül az első sikeres modell az "N-modell" volt, mely egy kicsi és könnyű négyhengeres autó volt és 500 dollárért árulták. Az 1908-as év folyamán aztán megjelent a legendás "T-modell", melyből az elkövetkező tizenkilenc évben több mint 15 millió darabot adtak el. Amerika nem kevesebbet köszönhetett a "T-modellnek", mint azt, hogy elindulhatott a városiasodás útján.
                    
                    Az első Ford gépkocsit egy chicagói fogorvos, egy bizonyos Mr. Pfennig vásárolta. Ezzel a Ford megtette az első lépést, hogy a világ egyik vezető autógyártójává nője ki magát. 1914-re már minden második autó a Ford gyárból került ki. A fokozatos növekedés külföldi terjeszkedést tett szükségessé. A Ford Motor Company az első külföldi gyárat Kanadában, Walkerville-ben alapította. A Ford autók az autópiac minden kategóriájában uralták a piacot. Az első komolyabb európai megjelenést az 1931-ben, Kölnben megnyitott gyár jelentette.
                    
                    1942-ben a Ford Motor Company is, mint minden más amerikai gyár a haditermelésre állt át. A háborús termelési program eredményeként a gyár több mint 8000 bombázó repülőgépet, 5700 repülőmotort és mintegy 250 ezer dzsipet, tankot és más háborús gépet szállított az Egyesült Államok hadseregének.
                </p>
                <a href="/" class="btn btn-primary py-2 px-5 m-1">Kezdőlap</a>
                <a href="/Boiling" class="btn btn-primary py-2 px-5 m-1">Forrás</a>
                <div class="col-lg-12 text-center"  style="min-height: 100px;">
                    <img class="mb-4"  src="../assets/img/History/oldFord.jpg" alt="OldCar" width="50%" height="50%">
                </div>

                
            </div>
        </div>
    </div>
<!-- Bemutatkozás vége -->
</template>