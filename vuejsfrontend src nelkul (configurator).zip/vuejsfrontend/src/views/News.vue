<script setup>

</script>


<template>


<!-- kezd -->
<div class="container-fluid p-0 mb-5" > 
        <div id="header-carousel" class="carousel slide" data-bs-ride="carousel" >
            <div class="carousel-inner" >
                <div class="carousel-item active" >
                    <img style="width:100%; height: 500px;" src="../assets/img/Header/news header.jpg" alt="News" >
                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 800px;">
                            <h1 class="display-2 text-white text-uppercase mb-md-4">Hírek</h1>                   
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- kezd Vége -->

    


<!-- Bemutatkozás -->
    <div class="container-fluid p-5">
        <div class="row gx-5">

            <div class="col-lg-12">
                <div class="mb-4">
                    <h3 class="display-6 text-uppercase mb-0">xy modell </h3>
                </div>
                
                

                <p class="mb-4"> 
                   megjelenés stb... info....
                </p>


                <div class="col-lg-12 text-center"  style="min-height: 100px;">
                    <img class="mb-4"  src="" alt="News1" width="50%" height="50%">
                </div>



                <div class="mb-4">
                    <h3 class="display-6 text-uppercase mb-0">xy modell</h3>
                </div>
                
                

                <p class="mb-4"> 
                    megjelenés stb... info....
                </p>
                

                <div class="col-lg-12 text-center"  style="min-height: 100px;">
                    <img class="mb-4"  src="" alt="News2" width="50%" height="50%">
                </div>

                <a href="" class="btn btn-primary py-2 px-5">Kezdőlap</a>
            </div>
        </div>
    </div>
<!-- Bemutatkozás vége -->

</template>