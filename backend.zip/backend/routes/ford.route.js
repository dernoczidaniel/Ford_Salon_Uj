module.exports = (app) =>{
    const router = require('express').Router(); // router tárolja a útvonalakat
    const ford = require('../controllers/ford.controller');

    router.get('/delivery-names',ford.getall)
    
    app.use('/api',router); // default route név
}